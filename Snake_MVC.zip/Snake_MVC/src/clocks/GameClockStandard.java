package clocks;

import actions.Collision;
import game.Snake;

public class GameClockStandard extends Thread{
    public static boolean running = true;
    
    public int sleepTime = 500;

    public void run(){
    	Snake.addInitialLength();
        while(running){
            try {
                sleep(sleepTime);
                Snake.move();
                Snake.waitToMove = false;
                Collision.collidePickUp();
                
                if(sleepTime > 150) {
                	sleepTime-= Snake.score;
                }
                                                	
                	if(Collision.collideSelf() || Collision.collideWall()){
                    	Snake.tails.clear();
                    	Snake.head.setX(7);
                    	Snake.head.setY(7);
                    	Snake.score = 0;
                    	sleepTime=500;
                    	
                	}
                
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

}
