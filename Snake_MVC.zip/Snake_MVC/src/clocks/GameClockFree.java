package clocks;

import actions.Collision;
import game.Snake;
import gui.Gui;

public class GameClockFree extends Thread{
    public static boolean running = true;
    
    public int sleepTime = 500;

    public void run(){
    	Snake.addInitialLength();
        while(running){
            try {
                sleep(sleepTime);
                Snake.move();
                Snake.waitToMove = false;
                Collision.collidePickUp();
                
                	if(sleepTime > 150) {
                		sleepTime-= Snake.score;
                	}
                	
                	if(Collision.collideWall()) {
                		               		
                		if(Snake.head.getX() > 15) {               			
                			Snake.head.setX(0);               
                		}else if(Snake.head.getX() < 0){
                			Snake.head.setX(15);
                		}else if(Snake.head.getY() > 15) {
                			Snake.head.setY(0);
                		}else if(Snake.head.getY() < 0) {
                			Snake.head.setY(15);
                		}
                		
                	}
                
                	if(Collision.collideSelf()){
                    	Snake.tails.clear();
                    	Snake.head.setX(7);
                    	Snake.head.setY(7);
                    	Snake.score = 0;
                    	sleepTime=500;
                    	
                	}
                
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

}
